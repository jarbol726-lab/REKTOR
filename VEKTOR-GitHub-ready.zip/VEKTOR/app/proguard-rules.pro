# VEKTOR ProGuard rules (keep minimal for now)
-keep class com.vektor.launcher.data.** { *; }
