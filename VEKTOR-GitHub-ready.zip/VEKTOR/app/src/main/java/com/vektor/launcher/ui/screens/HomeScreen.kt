package com.vektor.launcher.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vektor.launcher.ui.components.PrimaryButton
import com.vektor.launcher.ui.components.VektorCard
import com.vektor.launcher.ui.theme.*
import com.vektor.launcher.util.MinecraftLauncher

@Composable
fun HomeScreen(
    onNavigateToHud: () -> Unit,
    onNavigateToSensitivity: () -> Unit,
    onNavigateToProfiles: () -> Unit,
    onNavigateToPerformance: () -> Unit
) {
    val context = LocalContext.current
    val installed = MinecraftLauncher.isMinecraftInstalled(context)
    val version = MinecraftLauncher.getVersionName(context)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(VektorBg)
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        // Header / Logo area
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
                .background(
                    Brush.verticalGradient(
                        listOf(VektorPrimary.copy(0.25f), Color.Transparent)
                    ),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp)
                )
                .padding(20.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Column {
                Text(
                    "VEKTOR",
                    fontSize = 36.sp,
                    fontWeight = FontWeight.Black,
                    color = VektorText,
                    letterSpacing = 4.sp
                )
                Text(
                    "Mobile Control Companion",
                    fontSize = 14.sp,
                    color = VektorAccent,
                    fontWeight = FontWeight.Medium
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    "Legal launcher & HUD profile manager\nfor Minecraft Bedrock",
                    fontSize = 12.sp,
                    color = VektorTextSecondary,
                    lineHeight = 16.sp
                )
            }
        }

        Spacer(Modifier.height(24.dp))

        // Status card
        VektorCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    if (installed) Icons.Default.CheckCircle else Icons.Default.Warning,
                    contentDescription = null,
                    tint = if (installed) VektorSuccess else VektorDanger,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(
                        if (installed) "Minecraft Bedrock detected" else "Minecraft not installed",
                        color = VektorText,
                        fontWeight = FontWeight.SemiBold
                    )
                    if (installed && version != null) {
                        Text("Version: $version", color = VektorTextSecondary, fontSize = 13.sp)
                    } else if (!installed) {
                        Text("Install from Google Play to continue", color = VektorTextSecondary, fontSize = 13.sp)
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        PrimaryButton(
            text = if (installed) "Launch Minecraft" else "Open Google Play",
            onClick = { MinecraftLauncher.launch(context) }
        )

        Spacer(Modifier.height(28.dp))

        Text("Quick Access", color = VektorText, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Spacer(Modifier.height(12.dp))

        Row(Modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            QuickTile(
                title = "HUD Editor",
                subtitle = "Layout & buttons",
                icon = Icons.Default.DashboardCustomize,
                modifier = Modifier.weight(1f),
                onClick = onNavigateToHud
            )
            QuickTile(
                title = "Sensitivity",
                subtitle = "Camera profiles",
                icon = Icons.Default.Tune,
                modifier = Modifier.weight(1f),
                onClick = onNavigateToSensitivity
            )
        }

        Spacer(Modifier.height(12.dp))

        Row(Modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            QuickTile(
                title = "Profiles",
                subtitle = "Saved configs",
                icon = Icons.Default.Folder,
                modifier = Modifier.weight(1f),
                onClick = onNavigateToProfiles
            )
            QuickTile(
                title = "Tips",
                subtitle = "Performance",
                icon = Icons.Default.Speed,
                modifier = Modifier.weight(1f),
                onClick = onNavigateToPerformance
            )
        }

        Spacer(Modifier.height(32.dp))

        VektorCard {
            Text("Important Notice", color = VektorAccent, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(
                "VEKTOR is a companion app only. It does not inject into Minecraft, " +
                "does not modify game memory, and does not bypass any anti-cheat.\n\n" +
                "All control customization must be applied inside the official Minecraft " +
                "Settings → Touch menu or via legal Resource Packs.\n\n" +
                "The HUD editor helps you design and save ideal layouts so you can " +
                "recreate them accurately in-game.",
                color = VektorTextSecondary,
                fontSize = 13.sp,
                lineHeight = 18.sp
            )
        }

        Spacer(Modifier.height(40.dp))
    }
}

@Composable
private fun QuickTile(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    VektorCard(modifier = modifier, onClick = onClick) {
        Icon(icon, contentDescription = null, tint = VektorPrimary, modifier = Modifier.size(28.dp))
        Spacer(Modifier.height(10.dp))
        Text(title, color = VektorText, fontWeight = FontWeight.SemiBold)
        Text(subtitle, color = VektorTextSecondary, fontSize = 12.sp)
    }
}
