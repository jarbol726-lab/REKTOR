package com.vektor.launcher.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import com.vektor.launcher.data.SavedCommand
import com.vektor.launcher.ui.theme.VektorAccent
import com.vektor.launcher.ui.theme.VektorCard
import com.vektor.launcher.ui.theme.VektorTextSecondary

@Composable
fun CommandsScreen(
    commands: List<SavedCommand>,
    onSave: (SavedCommand) -> Unit,
    onDelete: (String) -> Unit
) {
    val clipboard = LocalClipboardManager.current
    var editing by remember { mutableStateOf<SavedCommand?>(null) }
    var showEditor by remember { mutableStateOf(false) }
    var copiedId by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("Commands", style = MaterialTheme.typography.headlineMedium)
                Text("Сохраняй команды и копируй их одним нажатием", color = VektorTextSecondary, style = MaterialTheme.typography.bodySmall)
            }
            FilledTonalIconButton(onClick = { editing = null; showEditor = true }) {
                Icon(Icons.Default.Add, contentDescription = "Добавить")
            }
        }
        Spacer(Modifier.height(16.dp))
        if (commands.isEmpty()) {
            Card(colors = CardDefaults.cardColors(containerColor = VektorCard)) {
                Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Пока нет команд")
                    Text("Нажми +, чтобы добавить первую команду", color = VektorTextSecondary)
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(commands, key = { it.id }) { command ->
                    Card(colors = CardDefaults.cardColors(containerColor = VektorCard)) {
                        Column(Modifier.fillMaxWidth().padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(command.name, style = MaterialTheme.typography.titleMedium)
                                    Text(command.command, color = VektorAccent, style = MaterialTheme.typography.bodyMedium)
                                }
                                IconButton(onClick = { editing = command; showEditor = true }) { Icon(Icons.Default.Edit, contentDescription = "Изменить") }
                                IconButton(onClick = { onDelete(command.id) }) { Icon(Icons.Default.Delete, contentDescription = "Удалить", tint = MaterialTheme.colorScheme.error) }
                            }
                            Spacer(Modifier.height(8.dp))
                            Button(onClick = {
                                clipboard.setText(AnnotatedString(command.command))
                                copiedId = command.id
                            }, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.ContentCopy, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text(if (copiedId == command.id) "Скопировано" else "Копировать команду")
                            }
                        }
                    }
                }
            }
        }
    }

    if (showEditor) {
        var name by remember(editing?.id) { mutableStateOf(editing?.name.orEmpty()) }
        var command by remember(editing?.id) { mutableStateOf(editing?.command.orEmpty()) }
        AlertDialog(
            onDismissRequest = { showEditor = false },
            title = { Text(if (editing == null) "Новая команда" else "Изменить команду") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Название") }, singleLine = true)
                    OutlinedTextField(value = command, onValueChange = { command = it }, label = { Text("Команда") }, placeholder = { Text("/hub") }, singleLine = true)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val clean = command.trim()
                    if (name.isNotBlank() && clean.isNotBlank()) {
                        onSave(SavedCommand(id = editing?.id ?: java.util.UUID.randomUUID().toString(), name = name.trim(), command = clean))
                        showEditor = false
                    }
                }) { Text("Сохранить") }
            },
            dismissButton = { TextButton(onClick = { showEditor = false }) { Text("Отмена") } }
        )
    }
}
