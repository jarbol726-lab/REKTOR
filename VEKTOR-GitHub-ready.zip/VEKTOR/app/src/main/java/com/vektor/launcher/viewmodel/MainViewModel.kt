package com.vektor.launcher.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.vektor.launcher.data.AppSettings
import com.vektor.launcher.data.HudProfile
import com.vektor.launcher.data.ProfileRepository
import com.vektor.launcher.data.SensitivityProfile
import com.vektor.launcher.data.SavedCommand
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = ProfileRepository(application)

    val hudProfiles: StateFlow<List<HudProfile>> = repo.hudProfiles
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val sensitivityProfiles: StateFlow<List<SensitivityProfile>> = repo.sensitivityProfiles
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val commands: StateFlow<List<SavedCommand>> = repo.commands
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val settings: StateFlow<AppSettings> = repo.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())

    init {
        viewModelScope.launch {
            repo.loadAll()
        }
    }

    fun saveHud(profile: HudProfile) {
        viewModelScope.launch { repo.addOrUpdateHud(profile) }
    }

    fun deleteHud(id: String) {
        viewModelScope.launch { repo.deleteHud(id) }
    }

    fun saveSensitivity(profile: SensitivityProfile) {
        viewModelScope.launch { repo.addOrUpdateSensitivity(profile) }
    }

    fun deleteSensitivity(id: String) {
        viewModelScope.launch { repo.deleteSensitivity(id) }
    }

    fun saveCommand(command: SavedCommand) {
        viewModelScope.launch { repo.addOrUpdateCommand(command) }
    }

    fun deleteCommand(id: String) {
        viewModelScope.launch { repo.deleteCommand(id) }
    }

    fun updateSettings(settings: AppSettings) {
        viewModelScope.launch { repo.updateSettings(settings) }
    }
}
