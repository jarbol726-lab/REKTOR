package com.vektor.launcher.data

import android.content.Context
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Simple file-based repository for HUD and Sensitivity profiles.
 * Uses app-private storage. Fully offline, no network.
 */
class ProfileRepository(private val context: Context) {

    private val gson: Gson = GsonBuilder().setPrettyPrinting().create()
    private val profilesDir: File = File(context.filesDir, "profiles").also { it.mkdirs() }
    private val hudFile = File(profilesDir, "hud_profiles.json")
    private val sensFile = File(profilesDir, "sensitivity_profiles.json")
    private val settingsFile = File(profilesDir, "app_settings.json")
    private val commandsFile = File(profilesDir, "commands.json")

    private val _hudProfiles = MutableStateFlow<List<HudProfile>>(emptyList())
    val hudProfiles: StateFlow<List<HudProfile>> = _hudProfiles.asStateFlow()

    private val _sensitivityProfiles = MutableStateFlow<List<SensitivityProfile>>(emptyList())
    val sensitivityProfiles: StateFlow<List<SensitivityProfile>> = _sensitivityProfiles.asStateFlow()

    private val _settings = MutableStateFlow(AppSettings())
    private val _commands = MutableStateFlow<List<SavedCommand>>(emptyList())
    val commands: StateFlow<List<SavedCommand>> = _commands.asStateFlow()
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    suspend fun loadAll() = withContext(Dispatchers.IO) {
        if (!hudFile.exists()) {
            val defaultHud = DefaultProfiles.createDefaultHud()
            saveHudProfiles(listOf(defaultHud))
        } else {
            _hudProfiles.value = readList(hudFile)
        }

        if (!sensFile.exists()) {
            val defaultSens = DefaultProfiles.createDefaultSensitivity()
            saveSensitivityProfiles(listOf(defaultSens))
        } else {
            _sensitivityProfiles.value = readList(sensFile)
        }

        if (commandsFile.exists()) {
            _commands.value = readList(commandsFile)
        }

        if (settingsFile.exists()) {
            _settings.value = gson.fromJson(settingsFile.readText(), AppSettings::class.java)
                ?: AppSettings()
        }
    }

    suspend fun saveHudProfiles(list: List<HudProfile>) = withContext(Dispatchers.IO) {
        hudFile.writeText(gson.toJson(list))
        _hudProfiles.value = list
    }

    suspend fun saveSensitivityProfiles(list: List<SensitivityProfile>) = withContext(Dispatchers.IO) {
        sensFile.writeText(gson.toJson(list))
        _sensitivityProfiles.value = list
    }

    suspend fun saveCommands(list: List<SavedCommand>) = withContext(Dispatchers.IO) {
        commandsFile.writeText(gson.toJson(list))
        _commands.value = list
    }

    suspend fun addOrUpdateCommand(command: SavedCommand) {
        val current = _commands.value.toMutableList()
        val idx = current.indexOfFirst { it.id == command.id }
        if (idx >= 0) current[idx] = command else current.add(command)
        saveCommands(current)
    }

    suspend fun deleteCommand(id: String) {
        saveCommands(_commands.value.filterNot { it.id == id })
    }

    suspend fun updateSettings(settings: AppSettings) = withContext(Dispatchers.IO) {
        settingsFile.writeText(gson.toJson(settings))
        _settings.value = settings
    }

    suspend fun addOrUpdateHud(profile: HudProfile) {
        val current = _hudProfiles.value.toMutableList()
        val idx = current.indexOfFirst { it.id == profile.id }
        profile.updatedAt = System.currentTimeMillis()
        if (idx >= 0) current[idx] = profile else current.add(profile)
        saveHudProfiles(current)
    }

    suspend fun deleteHud(id: String) {
        saveHudProfiles(_hudProfiles.value.filter { it.id != id })
    }

    suspend fun addOrUpdateSensitivity(profile: SensitivityProfile) {
        val current = _sensitivityProfiles.value.toMutableList()
        val idx = current.indexOfFirst { it.id == profile.id }
        if (idx >= 0) current[idx] = profile else current.add(profile)
        saveSensitivityProfiles(current)
    }

    suspend fun deleteSensitivity(id: String) {
        saveSensitivityProfiles(_sensitivityProfiles.value.filter { it.id != id })
    }

    private inline fun <reified T> readList(file: File): List<T> {
        return try {
            val type = object : TypeToken<List<T>>() {}.type
            gson.fromJson(file.readText(), type) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }
}
