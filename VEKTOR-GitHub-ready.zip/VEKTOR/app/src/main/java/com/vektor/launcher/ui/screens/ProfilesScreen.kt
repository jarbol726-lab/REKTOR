package com.vektor.launcher.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vektor.launcher.data.HudProfile
import com.vektor.launcher.data.SensitivityProfile
import com.vektor.launcher.ui.components.VektorCard
import com.vektor.launcher.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun ProfilesScreen(
    hudProfiles: List<HudProfile>,
    sensProfiles: List<SensitivityProfile>,
    onEditHud: (HudProfile) -> Unit,
    onDeleteHud: (String) -> Unit,
    onBack: () -> Unit
) {
    val dateFormat = SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault())

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(VektorBg)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(VektorSurface)
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, null, tint = VektorText)
            }
            Text("Saved Profiles", color = VektorText, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text("HUD Layouts", color = VektorAccent, fontWeight = FontWeight.SemiBold)
            }
            items(hudProfiles, key = { it.id }) { profile ->
                VektorCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(profile.name, color = VektorText, fontWeight = FontWeight.SemiBold)
                            Text(
                                "${profile.buttons.size} buttons · ${dateFormat.format(Date(profile.updatedAt))}",
                                color = VektorTextSecondary,
                                fontSize = 12.sp
                            )
                            if (profile.description.isNotBlank()) {
                                Text(profile.description, color = VektorTextSecondary, fontSize = 12.sp, maxLines = 2)
                            }
                        }
                        IconButton(onClick = { onEditHud(profile) }) {
                            Icon(Icons.Default.Edit, null, tint = VektorPrimary)
                        }
                        IconButton(onClick = { onDeleteHud(profile.id) }) {
                            Icon(Icons.Default.Delete, null, tint = VektorDanger)
                        }
                    }
                }
            }

            item {
                Spacer(Modifier.height(12.dp))
                Text("Sensitivity Profiles", color = VektorAccent, fontWeight = FontWeight.SemiBold)
            }
            items(sensProfiles, key = { it.id }) { profile ->
                VektorCard {
                    Text(profile.name, color = VektorText, fontWeight = FontWeight.SemiBold)
                    Text(
                        "Camera: ${profile.cameraSensitivity.toInt()} · AutoJump: ${if (profile.autoJump) "ON" else "OFF"}",
                        color = VektorTextSecondary,
                        fontSize = 13.sp
                    )
                }
            }

            item { Spacer(Modifier.height(40.dp)) }
        }
    }
}
