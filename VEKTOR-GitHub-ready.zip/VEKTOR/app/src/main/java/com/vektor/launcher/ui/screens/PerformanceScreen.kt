package com.vektor.launcher.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vektor.launcher.ui.components.VektorCard
import com.vektor.launcher.ui.theme.*

@Composable
fun PerformanceScreen(onBack: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(VektorBg)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(VektorSurface)
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, null, tint = VektorText)
            }
            Text("Performance & Tips", color = VektorText, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }

        Column(
            modifier = Modifier
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            TipCard(
                title = "In-game Graphics",
                body = "For stable mobile PvP:\n" +
                        "• Render Distance: 8–12 chunks\n" +
                        "• Fancy Graphics: Off\n" +
                        "• Beautiful Skies: Off\n" +
                        "• Smooth Lighting: Off or Minimum\n" +
                        "• Particles: Minimal\n" +
                        "• View Bobbing: Off (helps aim consistency)"
            )
            TipCard(
                title = "Touch Controls (official)",
                body = "Minecraft → Settings → Touch:\n" +
                        "• Customize Control Layout — match your VEKTOR HUD profile\n" +
                        "• Button Size & Opacity — reduce clutter\n" +
                        "• Camera Sensitivity — use the value from your Sensitivity profile\n" +
                        "• Auto Jump — OFF for PvP\n" +
                        "• Crosshair Aiming — preferred for consistent hits"
            )
            TipCard(
                title = "Device Tips",
                body = "• Close background apps before playing\n" +
                        "• Enable Game Mode / Performance mode if available\n" +
                        "• Keep device cool — thermal throttling kills consistency\n" +
                        "• Use a stable 60+ FPS target\n" +
                        "• Avoid heavy resource packs during competitive play"
            )
            TipCard(
                title = "Legal Resource Packs",
                body = "You can improve button visibility with pure texture packs from MCPEDL / CurseForge:\n" +
                        "• Transparent / minimal buttons\n" +
                        "• Old-style D-Pad packs\n" +
                        "• Clean HUD packs\n\n" +
                        "These change only appearance and work on servers."
            )
            TipCard(
                title = "What VEKTOR does NOT do",
                body = "• No memory injection\n" +
                        "• No input automation\n" +
                        "• No reach / hitbox / velocity changes\n" +
                        "• No anti-cheat bypass\n" +
                        "• No modification of Minecraft process\n\n" +
                        "All real control changes happen inside the official client."
            )
            Spacer(Modifier.height(40.dp))
        }
    }
}

@Composable
private fun TipCard(title: String, body: String) {
    VektorCard(modifier = Modifier.padding(bottom = 12.dp)) {
        Text(title, color = VektorAccent, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(body, color = VektorTextSecondary, fontSize = 13.sp, lineHeight = 18.sp)
    }
}
