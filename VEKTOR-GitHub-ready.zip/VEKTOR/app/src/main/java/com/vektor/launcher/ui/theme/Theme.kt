package com.vektor.launcher.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val VektorBg = Color(0xFF0A0A0F)
val VektorSurface = Color(0xFF12121A)
val VektorCard = Color(0xFF1A1A24)
val VektorPrimary = Color(0xFF7C5CFF)
val VektorPrimaryVariant = Color(0xFF5A3FD9)
val VektorAccent = Color(0xFF00E5C0)
val VektorText = Color(0xFFF0F0F5)
val VektorTextSecondary = Color(0xFFA0A0B0)
val VektorDanger = Color(0xFFFF4D6A)
val VektorSuccess = Color(0xFF00C853)

private val DarkColorScheme = darkColorScheme(
    primary = VektorPrimary,
    onPrimary = Color.White,
    secondary = VektorAccent,
    onSecondary = Color.Black,
    background = VektorBg,
    onBackground = VektorText,
    surface = VektorSurface,
    onSurface = VektorText,
    surfaceVariant = VektorCard,
    onSurfaceVariant = VektorTextSecondary,
    error = VektorDanger,
    onError = Color.White
)

@Composable
fun VEKTORTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
