package com.vektor.launcher.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vektor.launcher.data.DefaultProfiles
import com.vektor.launcher.data.SensitivityProfile
import com.vektor.launcher.ui.components.PrimaryButton
import com.vektor.launcher.ui.components.VektorCard
import com.vektor.launcher.ui.theme.*

@Composable
fun SensitivityScreen(
    profiles: List<SensitivityProfile>,
    onSave: (SensitivityProfile) -> Unit,
    onBack: () -> Unit
) {
    var current by remember {
        mutableStateOf(profiles.firstOrNull() ?: DefaultProfiles.createDefaultSensitivity())
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(VektorBg)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(VektorSurface)
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, null, tint = VektorText)
            }
            Text("Sensitivity Profiles", color = VektorText, fontWeight = FontWeight.Bold, fontSize = 18.sp,
                modifier = Modifier.weight(1f))
            IconButton(onClick = { onSave(current) }) {
                Icon(Icons.Default.Save, null, tint = VektorPrimary)
            }
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            OutlinedTextField(
                value = current.name,
                onValueChange = { current = current.copy(name = it) },
                label = { Text("Profile name") },
                modifier = Modifier.fillMaxWidth(),
                colors = textFieldColors()
            )

            Spacer(Modifier.height(20.dp))

            VektorCard {
                Text("Camera Sensitivity", color = VektorText, fontWeight = FontWeight.SemiBold)
                Text("${current.cameraSensitivity.toInt()}", color = VektorAccent, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Slider(
                    value = current.cameraSensitivity,
                    onValueChange = { current = current.copy(cameraSensitivity = it) },
                    valueRange = 1f..100f,
                    colors = SliderDefaults.colors(thumbColor = VektorPrimary, activeTrackColor = VektorPrimary)
                )
                Text(
                    "Match this value in Minecraft → Settings → Touch → Camera Sensitivity",
                    color = VektorTextSecondary,
                    fontSize = 12.sp
                )
            }

            Spacer(Modifier.height(12.dp))

            VektorCard {
                SettingSwitch("Invert Y-Axis", current.invertY) {
                    current = current.copy(invertY = it)
                }
                SettingSwitch("Auto Jump", current.autoJump) {
                    current = current.copy(autoJump = it)
                }
                SettingSwitch("Sneak Toggle", current.sneakToggle) {
                    current = current.copy(sneakToggle = it)
                }
                SettingSwitch("Crosshair Aiming", current.crosshairAiming) {
                    current = current.copy(crosshairAiming = it)
                }
            }

            Spacer(Modifier.height(12.dp))

            VektorCard {
                Text("How to apply", color = VektorAccent, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text(
                    current.notes,
                    color = VektorTextSecondary,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
            }

            Spacer(Modifier.height(20.dp))
            PrimaryButton("Save Sensitivity Profile", onClick = { onSave(current) })
            Spacer(Modifier.height(40.dp))
        }
    }
}

@Composable
private fun SettingSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = VektorText, modifier = Modifier.weight(1f))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = VektorPrimary)
        )
    }
}

@Composable
private fun textFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = VektorText,
    unfocusedTextColor = VektorText,
    focusedBorderColor = VektorPrimary,
    unfocusedBorderColor = VektorTextSecondary.copy(0.4f),
    focusedLabelColor = VektorPrimary,
    unfocusedLabelColor = VektorTextSecondary,
    cursorColor = VektorPrimary
)
