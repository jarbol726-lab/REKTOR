package com.vektor.launcher.data

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import com.google.gson.annotations.SerializedName
import java.util.UUID

/**
 * Type of control button used in the HUD editor.
 * These map conceptually to Minecraft Bedrock touch actions.
 * Actual in-game binding must be done via official Settings → Touch.
 */
enum class ButtonType {
    JOYSTICK,      // Movement area (left side)
    LOOK,          // Camera look area (right side) - conceptual
    JUMP,
    SNEAK,
    SPRINT,
    ATTACK,
    USE,           // Place / interact
    INVENTORY,
    CHAT,
    PAUSE,
    HOTBAR_SLOT_1,
    HOTBAR_SLOT_2,
    HOTBAR_SLOT_3,
    HOTBAR_SLOT_4,
    HOTBAR_SLOT_5,
    HOTBAR_SLOT_6,
    HOTBAR_SLOT_7,
    HOTBAR_SLOT_8,
    HOTBAR_SLOT_9,
    CUSTOM
}

data class HudButton(
    val id: String = UUID.randomUUID().toString(),
    val type: ButtonType = ButtonType.CUSTOM,
    val label: String = "",
    /** Normalized position 0..1 relative to screen width/height */
    var x: Float = 0.1f,
    var y: Float = 0.7f,
    /** Normalized size */
    var width: Float = 0.12f,
    var height: Float = 0.08f,
    var opacity: Float = 0.75f,
    var visible: Boolean = true,
    var colorArgb: Long = 0xFF7C5CFF
)

data class SensitivityProfile(
    val id: String = UUID.randomUUID().toString(),
    var name: String = "Default Sensitivity",
    /** Recommended Camera Sensitivity (0-100 scale matching in-game) */
    var cameraSensitivity: Float = 50f,
    var mouseSensitivity: Float = 50f, // for controller / external
    var invertY: Boolean = false,
    var autoJump: Boolean = false,
    var sneakToggle: Boolean = true,
    var crosshairAiming: Boolean = true,
    var notes: String = "Apply these values manually in Minecraft → Settings → Touch / Controls"
)

data class HudProfile(
    val id: String = UUID.randomUUID().toString(),
    var name: String = "Default HUD",
    var createdAt: Long = System.currentTimeMillis(),
    var updatedAt: Long = System.currentTimeMillis(),
    var buttons: MutableList<HudButton> = mutableListOf(),
    var sensitivityId: String? = null,
    var description: String = ""
)

data class AppSettings(
    var lastUsedHudProfileId: String? = null,
    var lastUsedSensitivityId: String? = null,
    var darkTheme: Boolean = true,
    var showFpsHint: Boolean = true,
    var preferredMinecraftPackage: String = "com.mojang.minecraftpe"
)

/** Factory for a sensible default Nodebuff-oriented layout (visual only). */
object DefaultProfiles {

    fun createDefaultHud(): HudProfile {
        val buttons = mutableListOf(
            HudButton(
                type = ButtonType.JOYSTICK,
                label = "Move",
                x = 0.08f, y = 0.62f,
                width = 0.22f, height = 0.22f,
                opacity = 0.55f
            ),
            HudButton(
                type = ButtonType.JUMP,
                label = "Jump",
                x = 0.78f, y = 0.72f,
                width = 0.14f, height = 0.10f,
                opacity = 0.80f
            ),
            HudButton(
                type = ButtonType.SNEAK,
                label = "Sneak",
                x = 0.78f, y = 0.58f,
                width = 0.14f, height = 0.10f,
                opacity = 0.75f
            ),
            HudButton(
                type = ButtonType.SPRINT,
                label = "Sprint",
                x = 0.62f, y = 0.72f,
                width = 0.12f, height = 0.09f,
                opacity = 0.70f
            ),
            HudButton(
                type = ButtonType.ATTACK,
                label = "Attack",
                x = 0.82f, y = 0.42f,
                width = 0.13f, height = 0.13f,
                opacity = 0.85f,
                colorArgb = 0xFFFF4D6A
            ),
            HudButton(
                type = ButtonType.USE,
                label = "Use",
                x = 0.68f, y = 0.42f,
                width = 0.12f, height = 0.12f,
                opacity = 0.80f,
                colorArgb = 0xFF00E5C0
            ),
            HudButton(
                type = ButtonType.INVENTORY,
                label = "Inv",
                x = 0.88f, y = 0.12f,
                width = 0.09f, height = 0.07f,
                opacity = 0.65f
            )
        )
        return HudProfile(
            name = "Nodebuff Default",
            buttons = buttons,
            description = "Visual layout optimized for mobile Nodebuff. Recreate positions in Minecraft Settings → Touch → Customize."
        )
    }

    fun createDefaultSensitivity(): SensitivityProfile {
        return SensitivityProfile(
            name = "Nodebuff Recommended",
            cameraSensitivity = 68f,
            invertY = false,
            autoJump = false,
            sneakToggle = true,
            crosshairAiming = true,
            notes = "Recommended starting point for mobile Nodebuff.\n" +
                    "1. Open Minecraft → Settings → Touch\n" +
                    "2. Set Camera Sensitivity close to 65-75\n" +
                    "3. Disable Auto Jump\n" +
                    "4. Enable Crosshair aiming if available\n" +
                    "5. Adjust button sizes to match your HUD profile"
        )
    }
}
