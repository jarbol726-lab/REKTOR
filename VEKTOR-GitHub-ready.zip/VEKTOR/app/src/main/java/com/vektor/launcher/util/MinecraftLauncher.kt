package com.vektor.launcher.util

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast

object MinecraftLauncher {

    const val OFFICIAL_PACKAGE = "com.mojang.minecraftpe"

    fun isMinecraftInstalled(context: Context): Boolean {
        return try {
            context.packageManager.getPackageInfo(OFFICIAL_PACKAGE, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }

    /**
     * Launches the official Minecraft Bedrock app.
     * This is the only legal integration method available without injection.
     */
    fun launch(context: Context): Boolean {
        if (!isMinecraftInstalled(context)) {
            Toast.makeText(
                context,
                "Minecraft Bedrock is not installed. Please install it from Google Play.",
                Toast.LENGTH_LONG
            ).show()
            // Optionally open Play Store
            try {
                val market = Intent(Intent.ACTION_VIEW).apply {
                    data = Uri.parse("market://details?id=$OFFICIAL_PACKAGE")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(market)
            } catch (_: Exception) {
                val web = Intent(Intent.ACTION_VIEW).apply {
                    data = Uri.parse("https://play.google.com/store/apps/details?id=$OFFICIAL_PACKAGE")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(web)
            }
            return false
        }

        return try {
            val launchIntent = context.packageManager.getLaunchIntentForPackage(OFFICIAL_PACKAGE)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                true
            } else {
                Toast.makeText(context, "Cannot find launch activity for Minecraft", Toast.LENGTH_SHORT).show()
                false
            }
        } catch (e: Exception) {
            Toast.makeText(context, "Failed to launch: ${e.message}", Toast.LENGTH_SHORT).show()
            false
        }
    }

    /**
     * Returns basic version info if available (best-effort).
     */
    fun getVersionName(context: Context): String? {
        return try {
            context.packageManager.getPackageInfo(OFFICIAL_PACKAGE, 0).versionName
        } catch (_: Exception) {
            null
        }
    }
}
