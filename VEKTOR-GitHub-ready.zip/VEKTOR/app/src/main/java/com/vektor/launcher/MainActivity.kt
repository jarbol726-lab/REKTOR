package com.vektor.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.vektor.launcher.data.HudProfile
import com.vektor.launcher.ui.screens.*
import com.vektor.launcher.ui.theme.VEKTORTheme
import com.vektor.launcher.ui.theme.VektorBg
import com.vektor.launcher.viewmodel.MainViewModel

sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    data object Home : Screen("home", "Home", Icons.Default.Home)
    data object Hud : Screen("hud", "HUD", Icons.Default.DashboardCustomize)
    data object Sensitivity : Screen("sensitivity", "Sens", Icons.Default.Tune)
    data object Profiles : Screen("profiles", "Profiles", Icons.Default.Folder)
    data object Performance : Screen("performance", "Tips", Icons.Default.Speed)
    data object Commands : Screen("commands", "Commands", Icons.Default.Code)
    data object HudEditor : Screen("hud_editor", "Editor", Icons.Default.Edit)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            VEKTORTheme {
                val viewModel: MainViewModel = viewModel()
                VektorApp(viewModel)
            }
        }
    }
}

@Composable
fun VektorApp(viewModel: MainViewModel) {
    val navController = rememberNavController()
    val backStack by navController.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route

    val bottomItems = listOf(
        Screen.Home,
        Screen.Hud,
        Screen.Sensitivity,
        Screen.Profiles,
        Screen.Performance,
        Screen.Commands
    )

    var editingProfile by remember { mutableStateOf<HudProfile?>(null) }

    val hudProfiles by viewModel.hudProfiles.collectAsState()
    val sensProfiles by viewModel.sensitivityProfiles.collectAsState()
    val commands by viewModel.commands.collectAsState()

    Scaffold(
        containerColor = VektorBg,
        bottomBar = {
            if (currentRoute != Screen.HudEditor.route) {
                NavigationBar(
                    containerColor = com.vektor.launcher.ui.theme.VektorSurface
                ) {
                    bottomItems.forEach { screen ->
                        NavigationBarItem(
                            selected = currentRoute == screen.route,
                            onClick = {
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(screen.icon, contentDescription = screen.title) },
                            label = { Text(screen.title) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = com.vektor.launcher.ui.theme.VektorPrimary,
                                selectedTextColor = com.vektor.launcher.ui.theme.VektorPrimary,
                                indicatorColor = com.vektor.launcher.ui.theme.VektorPrimary.copy(0.15f),
                                unselectedIconColor = com.vektor.launcher.ui.theme.VektorTextSecondary,
                                unselectedTextColor = com.vektor.launcher.ui.theme.VektorTextSecondary
                            )
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            composable(Screen.Home.route) {
                HomeScreen(
                    onNavigateToHud = { navController.navigate(Screen.Hud.route) },
                    onNavigateToSensitivity = { navController.navigate(Screen.Sensitivity.route) },
                    onNavigateToProfiles = { navController.navigate(Screen.Profiles.route) },
                    onNavigateToPerformance = { navController.navigate(Screen.Performance.route) }
                )
            }
            composable(Screen.Hud.route) {
                // Simple entry to editor with current or default
                HudEditorScreen(
                    initialProfile = hudProfiles.firstOrNull(),
                    onSave = { profile ->
                        viewModel.saveHud(profile)
                    },
                    onBack = { navController.popBackStack() }
                )
            }
            composable(Screen.Sensitivity.route) {
                SensitivityScreen(
                    profiles = sensProfiles,
                    onSave = { viewModel.saveSensitivity(it) },
                    onBack = { navController.popBackStack() }
                )
            }
            composable(Screen.Profiles.route) {
                ProfilesScreen(
                    hudProfiles = hudProfiles,
                    sensProfiles = sensProfiles,
                    onEditHud = { profile ->
                        editingProfile = profile
                        navController.navigate(Screen.HudEditor.route)
                    },
                    onDeleteHud = { viewModel.deleteHud(it) },
                    onBack = { navController.popBackStack() }
                )
            }
            composable(Screen.Performance.route) {
                PerformanceScreen(onBack = { navController.popBackStack() })
            }
            composable(Screen.Commands.route) {
                CommandsScreen(
                    commands = commands,
                    onSave = { viewModel.saveCommand(it) },
                    onDelete = { viewModel.deleteCommand(it) }
                )
            }
            composable(Screen.HudEditor.route) {
                HudEditorScreen(
                    initialProfile = editingProfile,
                    onSave = {
                        viewModel.saveHud(it)
                        editingProfile = null
                        navController.popBackStack()
                    },
                    onBack = {
                        editingProfile = null
                        navController.popBackStack()
                    }
                )
            }
        }
    }
}
