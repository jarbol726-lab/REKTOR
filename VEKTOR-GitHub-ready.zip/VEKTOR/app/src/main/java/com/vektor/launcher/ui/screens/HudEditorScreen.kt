package com.vektor.launcher.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vektor.launcher.data.ButtonType
import com.vektor.launcher.data.DefaultProfiles
import com.vektor.launcher.data.HudButton
import com.vektor.launcher.data.HudProfile
import com.vektor.launcher.ui.components.PrimaryButton
import com.vektor.launcher.ui.components.SecondaryButton
import com.vektor.launcher.ui.theme.*
import kotlin.math.roundToInt

@Composable
fun HudEditorScreen(
    initialProfile: HudProfile? = null,
    onSave: (HudProfile) -> Unit,
    onBack: () -> Unit
) {
    var profile by remember {
        mutableStateOf(initialProfile?.copy(buttons = initialProfile.buttons.map { it.copy() }.toMutableList())
            ?: DefaultProfiles.createDefaultHud())
    }
    var selectedId by remember { mutableStateOf<String?>(null) }
    var editMode by remember { mutableStateOf(true) }

    val selectedButton = profile.buttons.find { it.id == selectedId }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(VektorBg)
    ) {
        // Top bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(VektorSurface)
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, null, tint = VektorText)
            }
            Column(modifier = Modifier.weight(1f)) {
                Text("HUD Editor", color = VektorText, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(profile.name, color = VektorTextSecondary, fontSize = 12.sp)
            }
            IconButton(onClick = { editMode = !editMode }) {
                Icon(
                    if (editMode) Icons.Default.Visibility else Icons.Default.Edit,
                    null,
                    tint = VektorAccent
                )
            }
            IconButton(onClick = {
                onSave(profile)
            }) {
                Icon(Icons.Default.Save, null, tint = VektorPrimary)
            }
        }

        // Canvas area
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(Color(0xFF0D0D14))
                .padding(8.dp)
        ) {
            // Fake game background hint
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .border(1.dp, Color.White.copy(0.08f), RoundedCornerShape(12.dp))
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF15151F))
            ) {
                // Crosshair center
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val cx = size.width / 2
                    val cy = size.height / 2
                    drawLine(Color.White.copy(0.3f), Offset(cx - 12, cy), Offset(cx + 12, cy), 1.5f)
                    drawLine(Color.White.copy(0.3f), Offset(cx, cy - 12), Offset(cx, cy + 12), 1.5f)
                }

                // Buttons
                profile.buttons.filter { it.visible }.forEach { btn ->
                    HudButtonView(
                        button = btn,
                        selected = btn.id == selectedId,
                        editable = editMode,
                        onSelect = { selectedId = btn.id },
                        onMove = { dx, dy, parentW, parentH ->
                            btn.x = (btn.x + dx / parentW).coerceIn(0f, 1f - btn.width)
                            btn.y = (btn.y + dy / parentH).coerceIn(0f, 1f - btn.height)
                            // Force recomposition
                            profile = profile.copy(buttons = profile.buttons.toMutableList())
                        },
                        onResize = { dw, dh, parentW, parentH ->
                            btn.width = (btn.width + dw / parentW).coerceIn(0.05f, 0.4f)
                            btn.height = (btn.height + dh / parentH).coerceIn(0.04f, 0.3f)
                            profile = profile.copy(buttons = profile.buttons.toMutableList())
                        }
                    )
                }
            }
        }

        // Bottom controls
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(VektorSurface)
                .padding(12.dp)
        ) {
            if (selectedButton != null && editMode) {
                Text("Selected: ${selectedButton.label.ifEmpty { selectedButton.type.name }}",
                    color = VektorText, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Text("Opacity", color = VektorTextSecondary, fontSize = 12.sp)
                Slider(
                    value = selectedButton.opacity,
                    onValueChange = {
                        selectedButton.opacity = it
                        profile = profile.copy(buttons = profile.buttons.toMutableList())
                    },
                    valueRange = 0.15f..1f,
                    colors = SliderDefaults.colors(thumbColor = VektorPrimary, activeTrackColor = VektorPrimary)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = selectedButton.visible,
                        onClick = {
                            selectedButton.visible = !selectedButton.visible
                            profile = profile.copy(buttons = profile.buttons.toMutableList())
                        },
                        label = { Text(if (selectedButton.visible) "Visible" else "Hidden") }
                    )
                    TextButton(onClick = {
                        profile.buttons.removeAll { it.id == selectedButton.id }
                        selectedId = null
                        profile = profile.copy(buttons = profile.buttons.toMutableList())
                    }) {
                        Text("Delete", color = VektorDanger)
                    }
                }
            } else {
                Text(
                    "Tap a button to select. Drag to move. Use bottom bar to add buttons.",
                    color = VektorTextSecondary,
                    fontSize = 13.sp
                )
            }

            Spacer(Modifier.height(8.dp))

            // Add buttons
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val addable = listOf(
                    ButtonType.JUMP to "Jump",
                    ButtonType.SNEAK to "Sneak",
                    ButtonType.SPRINT to "Sprint",
                    ButtonType.ATTACK to "Attack",
                    ButtonType.USE to "Use",
                    ButtonType.INVENTORY to "Inv",
                    ButtonType.JOYSTICK to "Joystick"
                )
                items(addable) { (type, label) ->
                    AssistChip(
                        onClick = {
                            val newBtn = HudButton(
                                type = type,
                                label = label,
                                x = 0.4f,
                                y = 0.4f,
                                width = 0.12f,
                                height = 0.09f
                            )
                            profile.buttons.add(newBtn)
                            selectedId = newBtn.id
                            profile = profile.copy(buttons = profile.buttons.toMutableList())
                        },
                        label = { Text("+ $label") },
                        colors = AssistChipDefaults.assistChipColors(
                            containerColor = VektorCard,
                            labelColor = VektorText
                        )
                    )
                }
            }

            Spacer(Modifier.height(10.dp))
            PrimaryButton("Save Profile", onClick = { onSave(profile) })
        }
    }
}

@Composable
private fun HudButtonView(
    button: HudButton,
    selected: Boolean,
    editable: Boolean,
    onSelect: () -> Unit,
    onMove: (dx: Float, dy: Float, parentW: Float, parentH: Float) -> Unit,
    onResize: (dw: Float, dh: Float, parentW: Float, parentH: Float) -> Unit
) {
    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val parentW = constraints.maxWidth.toFloat()
        val parentH = constraints.maxHeight.toFloat()
        val density = LocalDensity.current

        val left = button.x * parentW
        val top = button.y * parentH
        val w = button.width * parentW
        val h = button.height * parentH

        val color = Color(button.colorArgb).copy(alpha = button.opacity)

        Box(
            modifier = Modifier
                .offset { IntOffset(left.roundToInt(), top.roundToInt()) }
                .size(
                    with(density) { w.toDp() },
                    with(density) { h.toDp() }
                )
                .clip(RoundedCornerShape(12.dp))
                .background(color)
                .border(
                    width = if (selected) 2.dp else 1.dp,
                    color = if (selected) VektorAccent else Color.White.copy(0.25f),
                    shape = RoundedCornerShape(12.dp)
                )
                .pointerInput(button.id, editable) {
                    if (!editable) return@pointerInput
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        onMove(dragAmount.x, dragAmount.y, parentW, parentH)
                        onSelect()
                    }
                }
                .pointerInput(button.id) {
                    // Simple tap to select
                    awaitPointerEventScope {
                        // selection handled by drag start mostly
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            Text(
                button.label.ifEmpty { button.type.name.take(3) },
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
