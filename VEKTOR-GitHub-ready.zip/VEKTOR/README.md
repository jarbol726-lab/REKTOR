# VEKTOR — Minecraft Bedrock Control Companion

**VEKTOR** is a clean, legal Android companion app for Minecraft Bedrock Edition focused on convenient mobile control management.

It is **not** a cheat client, injector, or mod loader.

## What it actually does

- Modern dark UI launcher
- One-tap launch of the **official** Minecraft Bedrock app (`com.mojang.minecraftpe`)
- Visual **HUD Editor** with multi-touch drag/resize support (design layouts offline)
- Multiple **HUD profiles** saved as JSON (button positions, sizes, opacity)
- **Sensitivity profiles** with recommended values and exact instructions how to apply them inside the official game
- Performance & legal tips for mobile PvP
- Fully offline, no network required for core features

## What it does **NOT** do

- Does not inject into the Minecraft process
- Does not modify memory, reach, hitboxes, velocity, or camera behaviour inside the game
- Does not automate input or bypass anti-cheat
- Does not replace the in-game touch controls at runtime

All real control changes must be performed by the player inside:

**Minecraft → Settings → Touch → Customize controls / Camera Sensitivity**

or via legal Resource Packs that only change button textures.

## Requirements

- Android 10+ (API 29)
- Official Minecraft Bedrock installed from Google Play
- Android Studio Ladybug / Koala or newer (for building)

## How to build the APK

1. Install [Android Studio](https://developer.android.com/studio)
2. Open the `VEKTOR` folder as a project
3. Let Gradle sync (Internet required once)
4. Connect a device or start an emulator
5. Click **Run** or build a release APK:

```bash
./gradlew assembleRelease
```

The APK will appear in `app/build/outputs/apk/release/`.

> Note: This repository does not contain a pre-built APK. You must compile it yourself.

## Project structure

```
VEKTOR/
├── app/
│   ├── src/main/
│   │   ├── java/com/vektor/launcher/
│   │   │   ├── MainActivity.kt
│   │   │   ├── data/          # Models + ProfileRepository
│   │   │   ├── ui/            # Compose screens & theme
│   │   │   ├── util/          # MinecraftLauncher helper
│   │   │   └── viewmodel/
│   │   ├── res/
│   │   └── AndroidManifest.xml
│   └── build.gradle.kts
├── build.gradle.kts
├── settings.gradle.kts
└── README.md
```

## Implemented & verified features (in this source)

| Feature                        | Status      | Notes |
|--------------------------------|-------------|-------|
| Project structure + Gradle     | Done        | Compiles in Android Studio |
| Dark minimal UI                | Done        | Jetpack Compose Material3 |
| Launch official Minecraft      | Done        | Via PackageManager Intent |
| Detect installed Minecraft     | Done        | Shows version if available |
| HUD visual editor              | Done        | Drag, resize, opacity, multi-button |
| Multi-touch in editor          | Done        | Compose pointerInput |
| Save / load HUD profiles       | Done        | JSON in app private storage |
| Sensitivity profiles           | Done        | Values + apply instructions |
| Multiple profiles management   | Done        | List / edit / delete |
| Performance tips               | Done        | Static educational content |
| Real in-game input injection   | **Not implemented** | Intentionally omitted (not legal/official) |
| Fixed Sensitivity / No Camera Reset / Item Delay Fix | **Not implemented** | Requires engine modification |

## Known limitations

1. The HUD editor is a **design tool only**. Buttons drawn in VEKTOR do not control the character inside Minecraft.
2. Sensitivity values are recommendations. You must set them manually in the official client.
3. No Resource Pack generation is included in this version (can be added later as pure texture pack export).
4. On some Android versions `QUERY_ALL_PACKAGES` may require additional Play Console declaration if you publish the app.

## Legal note

VEKTOR is provided for educational and convenience purposes.  
Respect Minecraft / Microsoft Terms of Service and Google Play policies.  
Do not use this project as a base for cheat clients.

---

Made as a clean alternative focused on real usability of official controls.
